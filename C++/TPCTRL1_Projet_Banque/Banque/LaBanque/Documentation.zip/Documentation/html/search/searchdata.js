var indexSectionsWithContent =
{
  0: "acdeilmnopqrst~",
  1: "cem",
  2: "clm",
  3: "acdeimor~",
  4: "clmnopst",
  5: "m",
  6: "cdimqr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Énumérations",
  6: "Valeurs énumérées"
};

