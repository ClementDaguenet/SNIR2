var files_dup =
[
    [ "barre.cpp", "barre_8cpp.html", null ],
    [ "barre.h", "barre_8h.html", [
      [ "Barre", "class_barre.html", "class_barre" ]
    ] ],
    [ "barrecarree.cpp", "barrecarree_8cpp.html", null ],
    [ "barrecarree.h", "barrecarree_8h.html", [
      [ "BarreCarree", "class_barre_carree.html", "class_barre_carree" ]
    ] ],
    [ "barrecarreecreuse.cpp", "barrecarreecreuse_8cpp.html", null ],
    [ "barrecarreecreuse.h", "barrecarreecreuse_8h.html", [
      [ "BarreCarreeCreuse", "class_barre_carree_creuse.html", "class_barre_carree_creuse" ]
    ] ],
    [ "barrerectangle.cpp", "barrerectangle_8cpp.html", null ],
    [ "barrerectangle.h", "barrerectangle_8h.html", [
      [ "BarreRectangle", "class_barre_rectangle.html", "class_barre_rectangle" ]
    ] ],
    [ "barrerectanglecreuse.cpp", "barrerectanglecreuse_8cpp.html", null ],
    [ "barrerectanglecreuse.h", "barrerectanglecreuse_8h.html", [
      [ "BarreRectangleCreuse", "class_barre_rectangle_creuse.html", "class_barre_rectangle_creuse" ]
    ] ],
    [ "barreronde.cpp", "barreronde_8cpp.html", null ],
    [ "barreronde.h", "barreronde_8h.html", [
      [ "BarreRonde", "class_barre_ronde.html", "class_barre_ronde" ]
    ] ],
    [ "barrerondecreuse.cpp", "barrerondecreuse_8cpp.html", null ],
    [ "barrerondecreuse.h", "barrerondecreuse_8h.html", [
      [ "BarreRondeCreuse", "class_barre_ronde_creuse.html", "class_barre_ronde_creuse" ]
    ] ],
    [ "libs.h", "libs_8h.html", null ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];